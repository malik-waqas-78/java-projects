package com.company;

import java.util.concurrent.Semaphore;

abstract class Car {
    String name;

}
